# -*- coding: utf-8 -*-
"""
Created on Sat Nov 18 18:22:02 2023

@author: kpodj
"""
# python C:\Users\kpodj\BigData_Project\run.py C:\Users\kpodj\BigData_Project\data\customer_churn.csv
# python C:\Users\kpodj\BigData_Project\run.py C:\Users\kpodj\BigData_Project\data\customer_churn.csv C:\Users\kpodj\BigData_Project\data\new_customers_test.csv

from flask import Flask, render_template, request, jsonify
from train_streams import train_model
import pandas as pd
import pickle
import os
# Vérifier s'il y a au moins un paramètre
paths = []
model =None
stdScaler = None
script_directory = os.path.dirname(os.path.abspath(__file__))

    
def train_on_data(df):  
    df['Churn'] = df['Churn'].astype(int)

    global paths
    paths = train_model(df)
    
    model_filename = paths[0]
    # Load the saved model
    global model
    with open(model_filename, 'rb') as file:
        model = pickle.load(file)
     
    model_filename = paths[1]
    # Load the saved model
    global stdScaler
    with open(model_filename, 'rb') as file:
        stdScaler = pickle.load(file)

def predict(X):
    X = stdScaler.transform(X)
    return model.predict_proba(X)

def labelize(dataframe):
    
    X = dataframe.iloc[:,1:].values
    X_probs = predict(X)
    seuil_min = 0.4
    seuil_max = 0.6
    predicted_labels = []

    # Iterate through the predicted probabilities
    for prob_vector,col in zip(X_probs,dataframe['Names']):
        # Determine the label based on the probability thresholds
        if prob_vector[0] < seuil_min:
            label = 0
        elif prob_vector[0] > seuil_max:
            label = 1
        else:
            label = 2
        
        # Append the label to the list
        predicted_labels.append([col,label])
    return predicted_labels

def prepare_dash(df2) :  
    df3 = pd.DataFrame()
    df3['Names'] = df2['Names']
    cols = list(paths[2])
    cols.pop()
    df3[cols] = df2[cols]
    
    df1 = pd.DataFrame(labelize(df3), columns=['Nom','Categorie'])
    diff_clients = df1.groupby(by='Categorie').size()
    
    clients_fideles = list(df1['Nom'][df1['Categorie']==0])
    clients_surveillance = list(df1['Nom'][df1['Categorie']==2])
    clients_depart = list(df1['Nom'][df1['Categorie']==1])
    return [diff_clients[0],diff_clients[1],diff_clients[2],clients_fideles,clients_surveillance,clients_depart]

app = Flask(__name__)
# Route principale pour le tableau de bord
@app.route('/api/endpoint', methods=['POST'])
def dashboard():
    try:
        # Récupérer les données JSON de la requête
        global json_data 
        try :
            json_data = request.get_json()
        except Exception as e:
            import json
            data_string = request.data.decode('utf-8')
            json_data = json.loads(data_string)

        output_file_path = './index/output.csv'

        # Vérifier si le répertoire du fichier existe, sinon le créer
        output_directory = os.path.dirname(output_file_path)
        if not os.path.exists(output_directory):
            os.makedirs(output_directory)
            df = pd.DataFrame(json_data, columns= ['Names',	'Age',	'Total_Purchase',	'Account_Manager',	'Years',
            'Num_Sites',	'Onboard_date',	'Location','Company','Churn'])
        else :
            df = pd.DataFrame(json_data, columns= ['Names',	'Age',	'Total_Purchase',	'Account_Manager',	'Years',
                'Num_Sites',	'Onboard_date',	'Location','Company','Churn'])
            df2 = pd.read_csv(output_file_path)
            df = pd.concat([df,df2], ignore_index=True)
        # Sauvegarder le DataFrame au format CSV
        df.to_csv(output_file_path, index=False)
        
        # Répondre avec un message de succès
        return jsonify({"message":"Data received successfully"}),200
    except Exception as e:
        print("Error processing request:", str(e))
        
        # Répondre avec un message d'erreur en cas d'échec
        return jsonify({"error":"Failed to process the request"}),500


# Route pour traiter la soumission du formulaire
@app.route('/submit_form', methods=['POST'])
def submit_form():
    names = request.form.get('names')
    age = request.form.get('age')
    Total_Purchase =request.form.get ('Total_Purchase')
    account_manager = request.form.get('account_manager')
    years = request.form.get('years')
    num_sites = request.form.get('num_sites')
    Onboard_date = request.form.get('Onboard_date')
    Location = request.form.get('Location')
    Company = request.form.get('Company')

    df = pd.DataFrame([[names,age,Total_Purchase,account_manager,years,num_sites,Onboard_date,Location,Company]], 
                      columns=['Names',	'Age',	'Total_Purchase',	'Account_Manager',	'Years',
                'Num_Sites',	'Onboard_date',	'Location','Company'])
    df3 = pd.DataFrame()
    df3['Names'] = df['Names']
    cols = list(paths[2])
    cols.pop()
    df3[cols] = df[cols]
    type_client = ['Fidèle','qui va partir','à surveiller']
    resp = type_client[labelize(df3)[0][1]]
    texte = ''+ names +' est un client ' +str(resp)

    return render_template('result.html', texte=texte)

@app.route('/newcustomer')
def index():
    return render_template('index.html')

def csv_to_json(csv_content):
    import csv, json

    # Assuming the CSV has a header row
    csv_reader = csv.DictReader(csv_content.splitlines())
    # Convert CSV data to a list of dictionaries
    csv_data = [row for row in csv_reader]
    # Convert the list to JSON
    json_data = json.dumps(csv_data)
    return json_data

@app.route('/upload', methods=['POST'])
def upload():
    if 'csvFile' in request.files:
        csv_file = request.files['csvFile']
        if csv_file.filename != '':
            # Read the content of the CSV file
            csv_content = csv_file.read().decode('utf-8')

            # Convert CSV content to JSON
            json_data = csv_to_json(csv_content)

            df = pd.read_json(json_data)
            resp_dash = prepare_dash(df)
            
            return render_template('dashboard.html',
                                   taux_clients_fideles=resp_dash[0],
                                   taux_clients_surveillance=resp_dash[2],
                                   taux_clients_depart=resp_dash[1],
                                   clients_fideles=resp_dash[3],
                                   clients_surveillance=resp_dash[4],
                                   clients_depart=resp_dash[5])

    return jsonify({"error": "No file selected or invalid file format."})


@app.route('/')
def init():            
        output_file_path = './index/output.csv'

        # Vérifier si le répertoire du fichier existe, sinon le créer
        output_directory = os.path.dirname(output_file_path)
        if not os.path.exists(output_directory):
            os.makedirs(output_directory)
            df = pd.DataFrame(json_data, columns= ['Names',	'Age',	'Total_Purchase',	'Account_Manager',	'Years',
            'Num_Sites',	'Onboard_date',	'Location','Company','Churn'])
        else :
            df = pd.DataFrame(json_data, columns= ['Names',	'Age',	'Total_Purchase',	'Account_Manager',	'Years',
                'Num_Sites',	'Onboard_date',	'Location','Company','Churn'])
            df2 = pd.read_csv(output_file_path)
            df = pd.concat([df,df2], ignore_index=True)
     
        df= pd.read_csv(output_file_path)
        train_on_data(df)

     
        # Sélectionner 10 lignes de type 1
        df_type_1 = df[df['Churn'] == 1].head(10)
    
        # Sélectionner 10 lignes de type 0
        df_type_0 = df[df['Churn'] == 0].head(10)
     
    
        # Concaténer les deux DataFrames
        df2 = pd.concat([df_type_1, df_type_0])
        resp_dash = prepare_dash(df2)
        return render_template('dashboard.html',
                           taux_clients_fideles=resp_dash[0],
                           taux_clients_surveillance=resp_dash[2],
                           taux_clients_depart=resp_dash[1],
                           clients_fideles=resp_dash[3],
                           clients_surveillance=resp_dash[4],
                           clients_depart=resp_dash[5])

def segmenter(json_data1) :
    df = pd.DataFrame(json_data1)
    resp_dash = prepare_dash(df)
    return render_template('dashboard.html',
                           taux_clients_fideles=resp_dash[0],
                           taux_clients_surveillance=resp_dash[2],
                           taux_clients_depart=resp_dash[1],
                           clients_fideles=resp_dash[3],
                           clients_surveillance=resp_dash[4],
                           clients_depart=resp_dash[5])
@app.route('/form')
def show_form():
    return render_template('form.html')
# Route pour traiter la soumission du formulaire

if __name__ == '__main__':
    app.run(debug=True)
