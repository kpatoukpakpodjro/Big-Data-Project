package fstt.lsi.bigdata.projet.controller;

import fstt.lsi.bigdata.projet.entity.*;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.StreamsBuilder;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.Produced;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.opencsv.exceptions.CsvException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;


//import javax.annotation.PostConstruct;
import jakarta.annotation.*;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.Properties;


@Controller
@RequestMapping("/")
public class CustomerChurnController {

    private final Properties props = new Properties();
    private final StreamsBuilder builder = new StreamsBuilder();
    private KStream<String, String> source;
    
    private boolean sd = true;
    
    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;
    
    
    @Autowired
    private CustomerChurnServices customerChurnServices;


    @PostConstruct
    public void setup() {
        props.put(StreamsConfig.APPLICATION_ID_CONFIG, "customer-churn-stream");
        props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        props.put(StreamsConfig.DEFAULT_KEY_SERDE_CLASS_CONFIG, Serdes.String().getClass());
        props.put(StreamsConfig.DEFAULT_VALUE_SERDE_CLASS_CONFIG, Serdes.String().getClass());

        source = builder.stream("customerchurntopicstreams");

        KafkaStreams streams = new KafkaStreams(builder.build(), props);
   
        streams.start();
        

        Runtime.getRuntime().addShutdownHook(new Thread(streams::close));
    }

    @GetMapping
    public String index(Model model) {
        model.addAttribute("customer", new Customer());
        return "customerForm";
    }

    @SuppressWarnings("unchecked")
	@PostMapping("/submit")
    public String submit(Customer customer, RedirectAttributes redirectAttributes) throws CsvException {
        // Convertir l'objet Customer en une chaîne JSON ou utilisez une autre méthode appropriée
        String customerJson = convertCustomerToJson(customer);

        // Produire l'enregistrement Kafka dans le topic customerchurntopic
        kafkaTemplate.send("customerchurntopicstreams", customerJson);
        
        if(sd == true) {
        	
        	// Appel du consommateur pour traiter le message Kafka
            customerChurnServices.sendToFlask();
            
        	sd = false;
        } else {
        	
            processCustomerJsonArray(customerJson);
        	
        	
        }
        

        System.out.println("New Record - Key: " + customer.getNames() + ", Value: " + customerJson);
        redirectAttributes.addFlashAttribute("successMessage", "Record submitted successfully!");
        return "redirect:/";
    }
    
    private void processCustomerJsonArray(String customerJson) {
        List<String> customerData = Arrays.asList(customerJson.split(","));

        JSONObject jsonObject = new JSONObject();
        JSONArray jsonArray = new JSONArray();

        jsonObject.put("Names", customerData.get(0));
        jsonObject.put("Age", Double.parseDouble(customerData.get(1)));
        jsonObject.put("Total_Purchase", Double.parseDouble(customerData.get(2)));
        jsonObject.put("Account_Manager", convertToBinary(customerData.get(3)));
        jsonObject.put("Years", Double.parseDouble(customerData.get(4)));
        jsonObject.put("Num_Sites", Double.parseDouble(customerData.get(5)));
        jsonObject.put("Onboard_date", formatDate(customerData.get(6)));
        jsonObject.put("Location", customerData.get(7));
        jsonObject.put("Company", customerData.get(8));
        jsonObject.put("Churn", convertToBinary(customerData.get(9)));
        jsonArray.add(jsonObject);

        customerChurnServices.sendJsonArrayToFlaskSolo(jsonArray);
    }

    // Ajout de la méthode pour convertir l'objet Customer en JSON
    private String convertCustomerToJson(Customer customer) {
        // Pour simplifier, on peut  utiliser la méthode toString de Customer
        return customer.toString();
    }
    
    private static int convertToBinary(String value) {
        return Boolean.parseBoolean(value) ? 1 : 0;
    }

    private static String formatDate(String date) {
        try {
            SimpleDateFormat inputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            SimpleDateFormat outputFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            Date parsedDate = inputFormat.parse(date);
            return outputFormat.format(parsedDate);
        } catch (ParseException e) {
            e.printStackTrace();
            return date; // En cas d'échec de la conversion, retourner la date d'origine
        }
    }
    
    
}

