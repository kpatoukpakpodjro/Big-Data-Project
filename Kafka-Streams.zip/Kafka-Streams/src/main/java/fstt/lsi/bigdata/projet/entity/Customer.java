	package fstt.lsi.bigdata.projet.entity;
	
	import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;
	
	public class Customer {
	
	    private String names;
	    private int age;
	    private double totalPurchase;
	    private boolean accountManager;
	    private int years;
	    private int numSites;
	    
	    
	    @DateTimeFormat(pattern = "yyyy-MM-dd")
	    private Date onboardDate;
	    
	    private String location;
	    private String company;
	    private boolean churn;
	
	    // Ajoutez les getters et setters ici
	
	    public String getNames() {
	        return names;
	    }
	
	    public void setNames(String names) {
	        this.names = names;
	    }
	
	    public int getAge() {
	        return age;
	    }
	
	    public void setAge(int age) {
	        this.age = age;
	    }
	
	    public double getTotalPurchase() {
	        return totalPurchase;
	    }
	
	    public void setTotalPurchase(double totalPurchase) {
	        this.totalPurchase = totalPurchase;
	    }
	
	    public boolean isAccountManager() {
	        return accountManager;
	    }
	
	    public void setAccountManager(boolean accountManager) {
	        this.accountManager = accountManager;
	    }
	
	    public int getYears() {
	        return years;
	    }
	
	    public void setYears(int years) {
	        this.years = years;
	    }
	
	    public int getNumSites() {
	        return numSites;
	    }
	
	    public void setNumSites(int numSites) {
	        this.numSites = numSites;
	    }
	
	    public Date getOnboardDate() {
	        return onboardDate;
	    }
	
	    public void setOnboardDate(Date onboardDate) {
	        this.onboardDate = onboardDate;
	    }
	
	    public String getLocation() {
	        return location;
	    }
	
	    public void setLocation(String location) {
	        this.location = location;
	    }
	
	    public String getCompany() {
	        return company;
	    }
	
	    public void setCompany(String company) {
	        this.company = company;
	    }
	
	    public boolean isChurn() {
	        return churn;
	    }
	
	    public void setChurn(boolean churn) {
	        this.churn = churn;
	    }
	
	    @Override
	    public String toString() {
	        return  names + 
	        		"," + age +
	                "," + totalPurchase +
	                "," + accountManager +
	                "," + years +
	                "," + numSites +
	                "," + onboardDate +
	                "," + location  +
	                "," + company  +
	                "," + churn 
	                ;
	    }
	}
