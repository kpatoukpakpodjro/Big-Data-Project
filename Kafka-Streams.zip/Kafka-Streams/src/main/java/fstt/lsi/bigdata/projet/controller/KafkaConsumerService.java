package fstt.lsi.bigdata.projet.controller;

import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

@Service
public class KafkaConsumerService {

    private List<String> accumulatedMessages = new ArrayList<>();

    private static final String FLASK_API_URL = "http://localhost:5000/api/endpoint";  // Remplacez par l'URL réel de votre API Flask

    public void consumeMessages() {
        Properties consumerProps = new Properties();
        consumerProps.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
        consumerProps.put(ConsumerConfig.GROUP_ID_CONFIG, "group-id");
        consumerProps.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        consumerProps.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());

        Consumer<String, String> consumer = new KafkaConsumer<>(consumerProps);
        consumer.subscribe(Collections.singletonList("customerchurntopicstreams"));

        while (true) {
            ConsumerRecords<String, String> records = consumer.poll(Duration.ofMillis(100));
            records.forEach(record -> {
                String jsonMessage = record.value();
                accumulatedMessages.add(jsonMessage);
            });

            // Envoyer l'ensemble des messages à l'application Flask à un moment opportun
            sendAccumulatedMessagesToFlask();
        }
    }

    private void sendAccumulatedMessagesToFlask() {
        if (!accumulatedMessages.isEmpty()) {
            // Convertir la liste en une chaîne JSON ou une autre structure JSON selon les besoins
            String messagesJson = convertListToJson(accumulatedMessages);

            // Envoyer la liste JSON à l'application Flask
            sendToFlask(messagesJson);

            // Effacer la liste accumulée
            accumulatedMessages.clear();
        }
    }

    private String convertListToJson(List<String> messages) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            // Convertir la liste en une chaîne JSON
            return objectMapper.writeValueAsString(messages);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
            // Gérer l'exception (par exemple, journaliser l'erreur)
            return ""; // Ou renvoyer une chaîne vide ou une valeur par défaut en cas d'erreur
        }
    }

    public void sendToFlask(String jsonMessage) {
        try {
            // Configuration des en-têtes HTTP
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);

            // Création de l'entité HTTP avec le corps de la requête
            HttpEntity<String> requestEntity = new HttpEntity<>(jsonMessage, headers);

            // Envoi de la requête HTTP POST
            RestTemplate restTemplate = new RestTemplate();
            ResponseEntity<String> responseEntity = restTemplate.postForEntity(FLASK_API_URL, requestEntity, String.class);
            
            // Gestion de la réponse (facultatif)
            if (responseEntity.getStatusCode().is2xxSuccessful()) {
                System.out.println("Message successfully sent to Flask API. Response: " + responseEntity.getBody());
            } else {
                System.err.println("Failed to send message to Flask API. Response: " + responseEntity.getBody());
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.err.println("Error sending message to Flask API: " + e.getMessage());
        }
    }
}
