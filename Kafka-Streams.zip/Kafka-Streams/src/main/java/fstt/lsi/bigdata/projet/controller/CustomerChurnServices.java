package fstt.lsi.bigdata.projet.controller;

import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvException;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.springframework.stereotype.Service;

import java.io.FileReader;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.io.OutputStream;
import java.util.List;


import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

@Service
public class CustomerChurnServices {


    public static JSONArray readCustomerChurnData() throws CsvException  {
        String csvFilePath = "/Applications/MAMP/htdocs/BigData_Project1/data/customer_churn1.csv";
        JSONArray jsonArray = new JSONArray();

        try (CSVReader csvReader = new CSVReaderBuilder(new FileReader(csvFilePath)).build()) {
            List<String[]> records = csvReader.readAll();

            String[] header = records.get(0);

            for (int i = 1; i < records.size(); i++) {
                JSONObject jsonObject = new JSONObject();
                String[] values = records.get(i);

                for (int j = 0; j < header.length; j++) {
                    jsonObject.put(header[j], values[j]);
                }

                jsonArray.add(jsonObject);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return jsonArray;
    }

    public static void sendJsonArrayToFlask(JSONArray jsonArray) {
        try {
            URL url = new URL("http://localhost:5000/api/endpoint"); // Replace with your Flask server endpoint
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();

            // Set the request method to POST
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Content-Type", "text/plain");
            connection.setDoOutput(true);

            // Write the JSON array to the output stream
            try (OutputStream os = connection.getOutputStream()) {
                os.write(jsonArray.toJSONString().getBytes());
            }

            // Get the response code
            int responseCode = connection.getResponseCode();
            System.out.println("POST Response Code: " + responseCode);

            // Close the connection
            connection.disconnect();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    
    public static void sendJsonArrayToFlaskSolo(JSONArray jsonArray) {
        try {
            URI uri = URI.create("http://localhost:5000/api/endpoint"); // Remplacez par votre endpoint Flask
            HttpClient httpClient = HttpClient.newHttpClient();

            HttpRequest request = HttpRequest.newBuilder()
                    .uri(uri)
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(jsonArray.toString()))
                    .build();

            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());

            int statusCode = response.statusCode();
            System.out.println("POST Response Code: " + statusCode);

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void sendToFlask() throws CsvException {
            JSONArray jsonArray = readCustomerChurnData();
            sendJsonArrayToFlask(jsonArray);
    }
    

}
